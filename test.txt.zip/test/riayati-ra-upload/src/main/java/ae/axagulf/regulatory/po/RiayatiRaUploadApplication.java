package ae.axagulf.regulatory.po;

import ae.axagulf.regulatory.po.email.EmailSenderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
//@PropertySource("file:\\\\wp0frs04.usergulf.intraxa\\CMU\\DXP\\INTEGRATION\\SOLUTIONS\\UAE_REGULATORY_PO\\RA\\DHPO\\ARTIFACTS\\dhpo-raupload.properties")
@PropertySource("file:C:\\CMU\\DXP\\INTEGRATION\\SOLUTIONS\\UAE_REGULATORY_PO\\RA\\Riayati\\ARTIFACTS\\Riayati-raupload.properties")
@EnableAsync
public class RiayatiRaUploadApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(RiayatiRaUploadApplication.class, args);
    }

    @Autowired
    EmailSenderService emailSenderService;

    @Override
    public void run(String... args) throws Exception {
    }


}
