package ae.axagulf.regulatory.po.config;


import ae.axagulf.soap.adapter.XPathEvaluator;
import ae.axagulf.soap.adapter.XmlUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.FileSystemResource;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableScheduling
public class ApplicationConfig {

    @Bean
    public XPathEvaluator xPathEvaluator() {
        return new XPathEvaluator();
    }

    @Bean
    public XmlUtils xmlUtils() {
        return new XmlUtils();
    }

}
