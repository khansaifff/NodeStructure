package ae.axagulf.regulatory.po.config;

import ae.axagulf.regulatory.po.utils.StringUtils;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import lombok.extern.log4j.Log4j2;
import org.springframework.context.annotation.Configuration;


import com.amazonaws.ClientConfiguration;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceAsync;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceAsyncClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.thymeleaf.spring5.SpringTemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.FileTemplateResolver;
import org.thymeleaf.templateresolver.ITemplateResolver;

import java.nio.charset.StandardCharsets;

@Configuration
@Log4j2
public class EmailConfig {

    @Value("${axa.http.proxy.host}")
    String httpProxyHost;

    @Value("${axa.http.proxy.port}")
    int httpProxyPort;

//    @Value("${axa.http.proxy.user}")
//    String httpProxyUser;
//
//    @Value("${axa.http.proxy.password}")
//    String httpProxyPassword;

    @Value("${axa.http.proxy.acs.key.id}")
    String httpProxyCred;

    @Value("${axa.http.proxy.auth.required}")
    boolean isHttpProxyAuthRequired;

//    @Value("${aws.profile.name}")
//    String awsProfileName;

    @Value("${aws.ses.acs.key.id}")
    String awsSesCred;

//    @Value("${aws.ses.secret.key.id}")
//    String awsSesSecretKeyId;


    @Value("${email.template.directory}")
    private String templatesDirectory;

    @Bean
    public SpringTemplateEngine springTemplateEngine() {
        SpringTemplateEngine templateEngine = new SpringTemplateEngine();
        templateEngine.addTemplateResolver(htmlTemplateResolver());
        return templateEngine;
    }

    @Bean
    public ITemplateResolver htmlTemplateResolver(){
        //SpringResourceTemplateResolver emailTemplateResolver = new SpringResourceTemplateResolver();
        //final ClassLoaderTemplateResolver emailTemplateResolver = new ClassLoaderTemplateResolver();
        //emailTemplateResolver.setPrefix("/templates/");
        FileTemplateResolver emailTemplateResolver = new FileTemplateResolver ();
        emailTemplateResolver.setPrefix(templatesDirectory);
        emailTemplateResolver.setSuffix(".html");
        emailTemplateResolver.setTemplateMode(TemplateMode.HTML);
        emailTemplateResolver.setCharacterEncoding(StandardCharsets.UTF_8.name());
        emailTemplateResolver.setCacheable(true);
        return emailTemplateResolver;
    }


    @Bean
    ClientConfiguration clientConfiguration() {
        ClientConfiguration config = new ClientConfiguration();
        config.setProxyHost(httpProxyHost);
        config.setProxyPort(httpProxyPort);
        if(isHttpProxyAuthRequired) {
            String decodedStr = StringUtils.decode(httpProxyCred.trim());
            String[] cred = decodedStr.split("/");
            String proxyUser = cred[0].trim();
            String proxyPwd = cred[1].trim();
            config.setProxyUsername(proxyUser);
            config.setProxyPassword(proxyPwd);
        }
        return config;
    }

    @Bean
    BasicAWSCredentials basicSessionCredentials(){
        String decodedStr = StringUtils.decode(awsSesCred.trim());
        String[] cred = decodedStr.split("@");
        String awsSesAccessKeyId = cred[0].trim();
        String awsSesSecretKeyId = cred[1].trim();
        //log.info("CRED >> {} ---- {}",awsSesAccessKeyId , awsSesSecretKeyId);
        return new BasicAWSCredentials(awsSesAccessKeyId, awsSesSecretKeyId);
    }

    @Bean
    AmazonSimpleEmailServiceAsync amazonSimpleEmailServiceAsync(ClientConfiguration clientConfiguration,
                                                                BasicAWSCredentials basicAWSCredentials){

        return AmazonSimpleEmailServiceAsyncClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials))
                .withClientConfiguration(clientConfiguration)
                //.withRegion(Regions.US_EAST_1).build();
                .withRegion(Regions.EU_CENTRAL_1).build();
    }

//    @Bean
//    ProfileCredentialsProvider profileCredentialsProvider(){
//        return new ProfileCredentialsProvider(awsProfileName);
//    }

//    @Bean
//    AmazonSimpleEmailServiceAsync amazonSimpleEmailServiceAsync(ClientConfiguration clientConfiguration,
//                                                                ProfileCredentialsProvider profileCredentialsProvider){
//
//        return AmazonSimpleEmailServiceAsyncClientBuilder.standard()
//                .withCredentials(profileCredentialsProvider)
//                .withClientConfiguration(clientConfiguration)
//                .withRegion(Regions.US_EAST_1).build();
//    }
}
