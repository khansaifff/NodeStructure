package ae.axagulf.regulatory.po.email;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
public class EmailAck {

    private int status;
    private String message;
    @JsonProperty("ack_id")
    private String ackId;
    @JsonProperty("msg_id")
    private String messageId;

}
