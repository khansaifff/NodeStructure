package ae.axagulf.regulatory.po.email;

public class EmailSender {
}
