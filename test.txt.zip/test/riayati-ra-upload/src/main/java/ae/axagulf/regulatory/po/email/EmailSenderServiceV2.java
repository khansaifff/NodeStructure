package ae.axagulf.regulatory.po.email;

import ae.axagulf.regulatory.po.model.RaUploadStatus;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceAsync;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.thymeleaf.spring5.SpringTemplateEngine;

import javax.mail.internet.InternetAddress;
import java.util.List;

public class EmailSenderServiceV2 implements EmailSenderService{

    @Autowired
    private SpringTemplateEngine templateEngine;

    @Autowired
    private Environment env;

    @Autowired
    private AmazonSimpleEmailServiceAsync awsSesClient;

    @Value("${riayati.ra.upload.notification.to.list}")
    private String[] raUploadNotificationToList;

    @Value("${riayati.ra.upload.notification.cc.list}")
    private String[] raUploadNotificationCcList;

    @Value("${riayati.ra.upload.notification.bcc.list}")
    private String[] raUploadNotificationBccList;

    @Value("${email.notification.enabled}")
    public boolean isNotificatioEnabled;

    @Autowired
    private JavaMailSender javaMailSender;

    @Async
    @Override
    public void sendNotification(List<RaUploadStatus> raUploadStatuses) {

        if (!isNotificatioEnabled) {
            System.out.println("EMAIL NOTIFICATION IS DISABLED !!!");
            return;
        }
    }

    @Async
    @Override
    public void sendEmail(SendEmailRequest sendEmailRequest){
        SimpleMailMessage mail = new SimpleMailMessage();
        try{
            mail.setTo(sendEmailRequest.getTo());
            mail.setFrom(
                    env.getProperty(
                            String.format("email.template.%s",sendEmailRequest.getTemplateId())));
            mail.setSubject(sendEmailRequest.getSubject());
            //mail.setText(sendEmailRequest.getText());
            javaMailSender.send(mail);

        }catch (Exception e){
            e.printStackTrace();
        }

    }

}
