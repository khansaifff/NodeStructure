package ae.axagulf.regulatory.po.email;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
@Builder
public class SendEmailRequest {
    @JsonProperty("src_app")
    private String sourceApp;
    @JsonProperty("template_id")
    private String templateId;
    private String[] to;
    private String[] cc;
    private String[] bcc;
    private String subject;
    @JsonProperty("template_data")
    private Map<String,Object> templateData;
    private List<Attachment> attachments;
}
