package ae.axagulf.regulatory.po.exceptions;

public class ExcelsheetExceedException extends RuntimeException {

    public ExcelsheetExceedException(String message){
        super(message);
    }
}
