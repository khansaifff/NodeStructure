package ae.axagulf.regulatory.po.handlers;

import ae.axagulf.regulatory.po.email.EmailSenderService;
import ae.axagulf.regulatory.po.exceptions.NonExistenceExcelDataSheetException;
import ae.axagulf.regulatory.po.model.RemittanceAdvice;
import ae.axagulf.regulatory.po.model.*;
import ae.axagulf.regulatory.po.model.Header;
import ae.axagulf.regulatory.po.services.RaUploadService;
import ae.axagulf.regulatory.po.utils.AppConstants;
import ae.axagulf.regulatory.po.utils.DateUtils;
import ae.axagulf.regulatory.po.utils.FileUtils;
import ae.axagulf.rest.adapter.CallResponseV2;
import ae.axagulf.soap.adapter.CallResponse;
import ae.axagulf.soap.adapter.StringUtils;
import ae.axagulf.soap.adapter.XPathEvaluator;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.*;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Component
@Log4j2
public class RiayatiRaGenerationHandler {


    @Value("${riayati.ra.dispositionflag}")
    String dispositionFlag;;

    @Value("${riayati.ra.upload.source.network.root.dir}")
    String raNetworkRootDir;

    @Value("${riayati.ra.upload.input.dir}")
    String raInputDir;

    @Value("${riayati.ra.upload.archive.dir}")
    String raArchiveDir;

    @Value("${riayati.ra.upload.invalid.dir}")
    String raInvalidDir;

    @Value("${riayati.ra.upload.success.dir}")
    String raSuccessDir;

    @Value("${riayati.ra.upload.failure.dir}")
    String raFailureDir;

    @Value("${riayati.ra.upload.file.read.limit}")
    int raUploadFileReadLimit;

    @Autowired
    RaUploadService raUploadService;

    @Autowired
    XPathEvaluator xPathEvaluator;

    @Autowired
    EmailSenderService emailSenderService;

    public static final int _TOTAL_EXCEL_CELLS_COUNT = 25;


    public RaUploadResponse extractRaUploadResponse(CallResponse dhpoCallResponse){
        RaUploadResponse raUploadResponse = new RaUploadResponse();
        try{
            String uploadStatusDesc = null;
            String uploadStatusCode = null;
            String errorReport = null;

//            if (dhpoCallResponse.getStatusCode() == 200) {
//                String responseBody = dhpoCallResponse.getSoapBodyXML();
//
//                uploadStatusCode =
//                        xPathEvaluator.getNodeValue(responseBody, "/UploadTransactionResponse/UploadTransactionResult/text()");
//                uploadStatusDesc =
//                        xPathEvaluator.getNodeValue(responseBody, "/UploadTransactionResponse/errorMessage/text()");
//                errorReport =
//                        xPathEvaluator.getNodeValue(responseBody, "/UploadTransactionResponse/errorReport/text()");
//
//                raUploadResponse.setUploadStatusCode(uploadStatusCode);
//                raUploadResponse.setUploadStatusDesc(uploadStatusDesc);
//                raUploadResponse.setErrorReport(errorReport);
//
//                log.info("UploadStatusCode: {} , Condition: {}",uploadStatusCode, "0".equalsIgnoreCase(uploadStatusCode));
//
//                if (!StringUtils.isNullOrEmpty(uploadStatusCode) &&
//                        "0".equalsIgnoreCase(uploadStatusCode)) {
//                    raUploadResponse.setUploadStatus("SUCCESS");
//                } else {
//                    raUploadResponse.setUploadStatus("FAILED");
//                }
//            } else {
//                raUploadResponse.setUploadStatus("API_INVOCATION_ERROR");
//                raUploadResponse.setUploadStatusDesc(dhpoCallResponse.getStatusDesc());
//            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return raUploadResponse;

    }

    private String getErrorReport(String encoded){
        if(StringUtils.isNullOrEmpty(encoded)) return null;
        byte[]  decodedBytes = Base64.getDecoder().decode(encoded.getBytes());
        return new String(decodedBytes);
    }

    public LinkedList<LinkedList<String>> readExcelRows(Path excel) {
        var excelRows = new LinkedList<LinkedList<String>>();
        try {
            InputStream excelFile = Files.newInputStream(excel);
            Workbook workbook = new HSSFWorkbook(excelFile);
            int raDataSheetIndex = getDataSheetIndex(workbook);
            if(getDataSheetIndex(workbook) < 0){
                throw new NonExistenceExcelDataSheetException(AppConstants._RA_EXCEL_DATA_SHEET_NOT_FOUND_MSG);
            }

            Sheet datatypeSheet = workbook.getSheetAt(raDataSheetIndex);
            log.info("READING DATA FROM EXCEL SHEET: {}", datatypeSheet.getSheetName());
            if(datatypeSheet == null){
                return null;
            }
            Iterator<Row> iterator = datatypeSheet.iterator();
            while (iterator.hasNext()) {
                var rowData = new LinkedList<String>();
                Row currentRow = iterator.next();
                Iterator<Cell> cellIterator = currentRow.iterator();
                //while (cellIterator.hasNext()) {
                for (int cn = 0; cn < _TOTAL_EXCEL_CELLS_COUNT; cn++){
                    Cell currentCell = currentRow.getCell(cn);//cellIterator.next();
                    if (currentCell == null || currentCell.getCellType() == CellType.BLANK) {
                        rowData.add("");
                    }else if (currentCell.getCellType() == CellType.STRING) {
                        rowData.add(currentCell.getStringCellValue () + "");
                    } else if (currentCell.getCellType() == CellType.NUMERIC) {
                        //System.out.println("Numeric: "+currentCell.getColumnIndex());
                        switch (currentCell.getColumnIndex()) {
                            // --------- ColumnIndex 3 refers Claim Id ---------
                            case 3:
                                //rowData.add(convertToString(currentCell.getNumericCellValue()));
                                rowData.add(new BigDecimal(currentCell.toString()).toPlainString());
                                break;
                            // --------- ColumnIndex 7 refers ClaimPaymentReference ---------
                            case 7:
                                if(currentCell != null){
                                    rowData.add(new BigDecimal(currentCell.toString()).toPlainString());
                                }
                                break;
                            // --------- ColumnIndex 9 refers Activity Id ---------
                            case 9:
                                rowData.add(convertToString(currentCell.getNumericCellValue()));
                                break;
                            default:
                                rowData.add(currentCell.getNumericCellValue () + "");
                                break;
                        }
                    }
//                    else if (currentCell.getCellType() == CellType.BLANK) {
//                        rowData.add("");
//                    }
                }
                if(!isEmptyRow(currentRow)){
                    excelRows.add(rowData);
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        log.info("Actual Size after processing: {}" , excelRows.size());
        return excelRows;
    }

    public int getDataSheetIndex(Workbook workbook){
        int invalidSheet = -1;
        var sheetIterater = workbook.sheetIterator();
        while(sheetIterater.hasNext()){
            var sheet = sheetIterater.next();
            var sheetIndex = workbook.getSheetIndex(sheet.getSheetName());
            if(!workbook.isSheetHidden(sheetIndex)
                    && !workbook.isSheetVeryHidden(sheetIndex)){
                return sheetIndex;
            }
        }
        return invalidSheet;
    }

    public ExcelDataProcessingOutput validateAndConvertExcelRowsToRaObjs(LinkedList<LinkedList<String>> excelRows){
        ExcelDataProcessingOutput excelDataProcessingOutput = new ExcelDataProcessingOutput();
        var validationErrors = new LinkedList<String>();
        validationErrors.add(AppConstants._RA_DATA_VALIDATION_ERRORS_HEADER_FORMAT);
        List<RaData> raDataList = new ArrayList<>();
        try{
            int numOfRows = excelRows.size();
            for (int i = 1; i < numOfRows; i++){
                RaData raData = new RaData();
                int index = 0;
                for(String s: excelRows.get(i)) {
                    String headerString = excelRows.get(0).get(index);
                    int excelRowNum = i+1; //This will deduct header record count
                    switch (headerString){
                        case "AXABatchNumber":
                            raData.setAxaBatchNumber(s);
                            break;
                        case AppConstants._EXCEL_ATTR_SENDER_ID:
                            if(StringUtils.isNullOrEmpty(s)){
                                validationErrors.add(
                                        String.format(AppConstants._RA_DATA_VALIDATION_ERRORS_FORMAT,
                                        excelRowNum,
                                        AppConstants._EXCEL_ATTR_SENDER_ID,
                                        AppConstants._RA_DATA_EMPTY_VALUE_ERROR));
                            }
                            raData.setSenderID(s);
                            break;
                        case AppConstants._EXCEL_ATTR_RECEIVER_ID:
                            if(StringUtils.isNullOrEmpty(s)){
                                validationErrors.add(
                                        String.format(AppConstants._RA_DATA_VALIDATION_ERRORS_FORMAT,
                                                excelRowNum,
                                                AppConstants._EXCEL_ATTR_RECEIVER_ID,
                                                AppConstants._RA_DATA_EMPTY_VALUE_ERROR));
                            }
                            raData.setReceiverID(s);
                            break;
                        case AppConstants._EXCEL_ATTR_CLAIM_ID:
                            if(StringUtils.isNullOrEmpty(s)){
                                validationErrors.add(
                                        String.format(AppConstants._RA_DATA_VALIDATION_ERRORS_FORMAT,
                                                excelRowNum,
                                                AppConstants._EXCEL_ATTR_CLAIM_ID,
                                                AppConstants._RA_DATA_EMPTY_VALUE_ERROR));
                            }
                            //System.out.println("CLAIM ID: "+s);
                            raData.setClaimID(s);
                            break;
                        case "Comments":
                            if(!StringUtils.isNullOrEmpty(s) && !isPureAscii(s)){
                                //log.info(String.format(">>>> INVALID AT ROW - %s:[%s]",excelRowNum,s));
                                //log.info(String.format(">>>> CORRECT AT ROW - %s:[%s]",excelRowNum,s));
                                raData.setComments(replaceInvalidChars(s));

                            }else{
                                raData.setComments(s);
                            }
                            break;
                        case "ClaimDenialCode":
                            if(!StringUtils.isNullOrEmpty(s)) {
                                raData.setClaimDenialCode(s);
                            }
                            break;
                        case AppConstants._EXCEL_ATTR_CLAIM_ID_PAYER:
                            if(StringUtils.isNullOrEmpty(s)){
                                validationErrors.add(
                                        String.format(AppConstants._RA_DATA_VALIDATION_ERRORS_FORMAT,
                                                excelRowNum,
                                                AppConstants._EXCEL_ATTR_CLAIM_ID_PAYER,
                                                AppConstants._RA_DATA_EMPTY_VALUE_ERROR));
                            }
                            raData.setClaimIDPayer(s);
                            break;
                        case AppConstants._EXCEL_ATTR_CLAIM_PAYMENT_REF:
                            if(StringUtils.isNullOrEmpty(s)){
                                validationErrors.add(
                                        String.format(AppConstants._RA_DATA_VALIDATION_ERRORS_FORMAT,
                                                excelRowNum,
                                                AppConstants._EXCEL_ATTR_CLAIM_PAYMENT_REF,
                                                AppConstants._RA_DATA_EMPTY_VALUE_ERROR));
                            }
                            raData.setClaimPaymentReference(s);
                            break;
                        case "ActivityUID":
                            raData.setActivityUID(s);
                            break;
                        case AppConstants._EXCEL_ATTR_ACTIVITY_ID:
                            if(StringUtils.isNullOrEmpty(s)){
                                validationErrors.add(
                                        String.format(AppConstants._RA_DATA_VALIDATION_ERRORS_FORMAT,
                                                excelRowNum,
                                                AppConstants._EXCEL_ATTR_ACTIVITY_ID,
                                                AppConstants._RA_DATA_EMPTY_VALUE_ERROR));
                            }
                            raData.setActivityId(s);
                            break;
                        case AppConstants._EXCEL_ATTR_ACTIVITY_START:
                            if(StringUtils.isNullOrEmpty(s)){
                                validationErrors.add(
                                        String.format(AppConstants._RA_DATA_VALIDATION_ERRORS_FORMAT,
                                                excelRowNum,
                                                AppConstants._EXCEL_ATTR_ACTIVITY_START,
                                                AppConstants._RA_DATA_EMPTY_VALUE_ERROR));
                            }
                            raData.setActivityStart(s);
                            break;
                        case AppConstants._EXCEL_ATTR_ACTIVITY_TYPE:
                            if(StringUtils.isNullOrEmpty(s)){
                                validationErrors.add(
                                        String.format(AppConstants._RA_DATA_VALIDATION_ERRORS_FORMAT,
                                                excelRowNum,
                                                AppConstants._EXCEL_ATTR_ACTIVITY_TYPE,
                                                AppConstants._RA_DATA_EMPTY_VALUE_ERROR));
                            }else{
                                raData.setActivityType((int)Double.parseDouble(s));
                            }
                            break;
                        case AppConstants._EXCEL_ATTR_ACTIVITY_CODE:
                            if(StringUtils.isNullOrEmpty(s)){
                                validationErrors.add(
                                        String.format(AppConstants._RA_DATA_VALIDATION_ERRORS_FORMAT,
                                                excelRowNum,
                                                AppConstants._EXCEL_ATTR_ACTIVITY_CODE,
                                                AppConstants._RA_DATA_EMPTY_VALUE_ERROR));
                            }
                            raData.setActivityCode(s);
                            break;
                        case AppConstants._EXCEL_ATTR_ACTIVITY_QUANTITY:
                            if(StringUtils.isNullOrEmpty(s)){
                                validationErrors.add(
                                        String.format(AppConstants._RA_DATA_VALIDATION_ERRORS_FORMAT,
                                                excelRowNum,
                                                AppConstants._EXCEL_ATTR_ACTIVITY_QUANTITY,
                                                AppConstants._RA_DATA_EMPTY_VALUE_ERROR));
                            }
                            raData.setActivityQuantity(s);
                            break;
                        case AppConstants._EXCEL_ATTR_ACTIVITY_NET:
                            if(StringUtils.isNullOrEmpty(s)){
                                validationErrors.add(
                                        String.format(AppConstants._RA_DATA_VALIDATION_ERRORS_FORMAT,
                                                excelRowNum,
                                                AppConstants._EXCEL_ATTR_ACTIVITY_NET,
                                                AppConstants._RA_DATA_EMPTY_VALUE_ERROR));
                            }
                            raData.setActivityNet(s);
                            break;
                        case "ActivityList":
                            if(!StringUtils.isNullOrEmpty(s)) {
                                raData.setActivityList(s);
                            }
                            break;
                        case AppConstants._EXCEL_ATTR_ACTIVITY_CLINICIAN:
                            if(StringUtils.isNullOrEmpty(s)){
                                validationErrors.add(
                                        String.format(AppConstants._RA_DATA_VALIDATION_ERRORS_FORMAT,
                                                excelRowNum,
                                                AppConstants._EXCEL_ATTR_ACTIVITY_CLINICIAN,
                                                AppConstants._RA_DATA_EMPTY_VALUE_ERROR));
                            }
                            raData.setActivityClinician(s);
                            break;
                        case "ActivityPriorAuthorizationID":
                            if(!StringUtils.isNullOrEmpty(s)) {
                                raData.setActivityPriorAuthorizationID(s);
                            }
                            break;
                        case "ActivityGross":
                            if(!StringUtils.isNullOrEmpty(s)) {
                                raData.setActivityGross(s);
                            }
                            break;
                        case "ActivityPatientShare":
                            if(!StringUtils.isNullOrEmpty(s)) {
                                raData.setActivityPatientShare(s);
                            }
                            break;
                        case AppConstants._EXCEL_ATTR_ACTIVITY_PAYMENT_AMOUNT:
                            if(StringUtils.isNullOrEmpty(s)){
                                validationErrors.add(
                                        String.format(AppConstants._RA_DATA_VALIDATION_ERRORS_FORMAT,
                                                excelRowNum,
                                                AppConstants._EXCEL_ATTR_ACTIVITY_PAYMENT_AMOUNT,
                                                AppConstants._RA_DATA_EMPTY_VALUE_ERROR));
                            }
                            raData.setActivityPaymentAmount(s);
                            break;
                        case "ActivityDenialCode":
                            if(!StringUtils.isNullOrEmpty(s)) {
                                raData.setActivityDenialCode(s);
                            }
                            break;
                        case "ProviderId":
                            if(!StringUtils.isNullOrEmpty(s)) {
                                raData.setProviderId(s);
                            }
                            break;
                        case "FacilityId":
                            if(!StringUtils.isNullOrEmpty(s)) {
                                raData.setFacilityId(s);
                            }
                            break;
                        case "DateofSettlement":
                            if(!StringUtils.isNullOrEmpty(s)){
                                raData.setDateofSettlement(s+" 12:00");
                            }
                            break;
                    }
                    index++;
                }
                if(!StringUtils.isNullOrEmpty(raData.getClaimID())){
                    raDataList.add(raData);
                }
            }

            if(validationErrors.size() > 1){
                excelDataProcessingOutput.setDataValidatioErrorsExist(true);
                excelDataProcessingOutput.setValidationErrors(validationErrors);
            }

            excelDataProcessingOutput.setRaDataList(raDataList);

        }catch (Exception e){
            e.printStackTrace();
        }
        return excelDataProcessingOutput;
    }

    public RemittanceAdvice convertRaObjsToRemittanceAdvice(List<RaData> raDataList){
        RemittanceAdvice remittanceAdvice = new RemittanceAdvice();
        try{
            //Group records by Claim Id
            var groupedData = groupByClaimId(raDataList);
            ae.axagulf.regulatory.po.model.Header header = new Header();
            header.setSenderID(getSenderId(raDataList));
            header.setReceiverID(getReceiverId(raDataList));
            header.setTransactionDate(
                    DateUtils.now(LocalDateTime.now(),
                            AppConstants._RA_TXN_DATE_FORMAT));
            header.setRecordCount(groupedData.size()+"");
            header.setDispositionFlag(dispositionFlag);
            remittanceAdvice.setHeader(header);
            List<Claim> claims = new LinkedList<>();

            for (Map.Entry<String,List<RaData>> entry : groupedData.entrySet()){
                String groupByKey = entry.getKey();
                RaData raData = entry.getValue().get(0);
                Claim claim = new Claim();
                claim.setId(raData.getClaimID());
                claim.setIdPayer(raData.getClaimIDPayer());
                claim.setProviderID(raData.getProviderId());
                claim.setPaymentReference(raData.getClaimPaymentReference());
                claim.setDateSettlement(raData.getDateofSettlement());
                claim.setComments(raData.getComments());
                Encounter encounter = new Encounter();
                encounter.setFacilityID(raData.getFacilityId());
                claim.setEncounter(encounter);
                //System.out.println("Group Key: "+groupByKey);
                //System.out.println("----------- Activities List Starts-----------");
                List<Activity> activities = new LinkedList<>();
                for(RaData record : entry.getValue()){
                    //System.out.println("Activity Id: "+record.getActivityId());
                    Activity activity = new Activity();
                    activity.setId(record.getActivityId());
                    activity.setStart(record.getActivityStart());
                    activity.setType(record.getActivityType());
                    activity.setCode(record.getActivityCode());
                    activity.setQuantity(record.getActivityQuantity());
                    activity.setNet(record.getActivityNet());
                    activity.setList(record.getActivityList());
                    activity.setClinician(record.getActivityClinician());
                    activity.setPriorAuthorizationID(record.getActivityPriorAuthorizationID());
                    activity.setGross(record.getActivityGross());
                    activity.setPatientShare(record.getActivityPatientShare());
                    activity.setPaymentAmount(record.getActivityPaymentAmount());
                    activity.setDenialCode(record.getActivityDenialCode());
                    activities.add(activity);
                }
                claim.setActivity(activities);
                claims.add(claim);
                //System.out.println("----------- Activities List Ends-----------");
            }
            remittanceAdvice.setClaim(claims);

        }catch (Exception e){
            e.printStackTrace();
        }
        return remittanceAdvice;
    }

    public Map<String, List<RaData>> groupByClaimId(List<RaData> raDataList){

        Map<String, List<RaData>> result = raDataList.stream()
                //.sorted(Comparator.comparing(RaData::getClaimID))
                .collect(Collectors.groupingBy(raData -> raData.getClaimID()));
        return result;
    }

    public static String convertToString(double in){
        try{
            return String.valueOf((int) in);
        }catch (Exception e){
            log.error("UNEXPECTED ERROR: {} ", e.getMessage());
            e.printStackTrace();
        }
        return in+"";
    }

    public String convertObjectToJson(Remittance remittanceAdvice){

            ObjectMapper mapper = new ObjectMapper();
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.UPPER_CAMEL_CASE);
            try {
                // convert user object to json string and return it
                return mapper.writeValueAsString(remittanceAdvice);
            }
            catch (JsonGenerationException | JsonMappingException e) {
                // catch various errors
                e.printStackTrace();
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }


        return null;
    }

    public String convertObjectToXml (RemittanceAdvice remittanceAdvice){
        JAXBContext jaxbContext;
        try
        {
            StringWriter sw = new StringWriter();

            jaxbContext = JAXBContext.newInstance(RemittanceAdvice.class);

            Marshaller jaxbmarshaller = jaxbContext.createMarshaller();

            jaxbmarshaller.marshal(remittanceAdvice, sw);
            String xmlString = sw.toString();
            return xmlString;
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }



    public boolean isEmptyRow(Row row){
        boolean isEmptyRow = true;
        for(int cellNum = row.getFirstCellNum(); cellNum < row.getLastCellNum(); cellNum++){
            Cell cell = row.getCell(cellNum);
            if(cell != null &&
                    cell.getCellType() != CellType.BLANK &&
                    org.apache.commons.lang3.StringUtils.isNotBlank(cell.toString())){
                return false;
            }
        }
        return isEmptyRow;
    }

    public static boolean isPureAscii(String v) {
        byte bytearray []  = v.getBytes();
        CharsetDecoder d = Charset.forName("US-ASCII").newDecoder();
        try {
            CharBuffer r = d.decode(ByteBuffer.wrap(bytearray));
            r.toString();
        }
        catch(CharacterCodingException e) {
            return false;
        }
        return true;
    }

    public static String replaceInvalidChars(String input){
        return input.replaceAll("[^\\p{ASCII}]", "");
    }

    public String getSenderId(List<RaData> raDataList){
        for (RaData data : raDataList) {
            if (!StringUtils.isNullOrEmpty(data.getSenderID())) {
                return data.getSenderID();
            }
        }
        return null;
    }

    public String getReceiverId(List<RaData> raDataList){
        for (RaData data : raDataList) {
            if (!StringUtils.isNullOrEmpty(data.getReceiverID())) {
                return data.getReceiverID();
            }
        }
        return null;
    }

    public boolean isValidFileExtension(Path path){
        String fileExtension = FilenameUtils.getExtension(path.getFileName().toString());
        if(!StringUtils.isNullOrEmpty(fileExtension)
                && "XLS".equalsIgnoreCase(fileExtension)){
            return true;
        }
        return false;
    }

    public void handleInvalidDataErrors(Path inputFile, List<String> validatioErrors){
        String currentDate =
                DateUtils.now(LocalDateTime.now(),AppConstants._RA_FOLDER_FORMAT);
        String fileNameWithoutExtension = FilenameUtils.removeExtension(inputFile.getFileName().toString());
        Path invalidRootDir = Paths.get(raNetworkRootDir).resolve(raInvalidDir);
        Path invalidDir =  getYearMonthDir(invalidRootDir).resolve(DateUtils.currentDate("MMddyyyy"));
        try {
            Path errorDir = invalidDir.resolve(currentDate.toUpperCase()+"_"+fileNameWithoutExtension);
            Files.createDirectories(errorDir);
            FileUtils.moveFile(inputFile, errorDir, inputFile.getFileName());
            Path validationFailureFile = errorDir.resolve("[INVALID-DATA-ERRORS]_"+fileNameWithoutExtension+".csv");
            Files.write(validationFailureFile,validatioErrors);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void handleInvalidFileErrors(Path inputFile, String errorName, String errorMsg){
        String currentDate =
                DateUtils.now(LocalDateTime.now(),AppConstants._RA_FOLDER_FORMAT);
        String fileNameWithoutExtension = FilenameUtils.removeExtension(inputFile.getFileName().toString());
        Path invalidRootDir = Paths.get(raNetworkRootDir).resolve(raInvalidDir);
        Path invalidDir =  getYearMonthDir(invalidRootDir).resolve(DateUtils.currentDate("MMddyyyy"));
        try {
            Path errorDir = invalidDir.resolve(currentDate.toUpperCase()+"_"+fileNameWithoutExtension);
            Files.createDirectories(errorDir);
            FileUtils.moveFile(inputFile, errorDir, inputFile.getFileName());
            Path validationFailureFile = errorDir.resolve(String.format("[%s]_%s.csv",errorName,fileNameWithoutExtension));
            Files.write(validationFailureFile,List.of(errorMsg));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void handleWrongExcelSheetName(Path inputFile){
        try {
            String currentDate =
                    DateUtils.now(LocalDateTime.now(),AppConstants._RA_FOLDER_FORMAT);
            String fileNameWithoutExtension = FilenameUtils.removeExtension(inputFile.getFileName().toString());
            Path invalidRootDir = Paths.get(raNetworkRootDir).resolve(raInvalidDir);
            Path invalidDir =  getYearMonthDir(invalidRootDir).resolve(DateUtils.currentDate("MMddyyyy"));
            Path errorDir = invalidDir.resolve(currentDate.toUpperCase()+"_"+fileNameWithoutExtension);
            Files.createDirectories(errorDir);
            FileUtils.moveFile(inputFile, errorDir, inputFile.getFileName());
            Path validationFailureFile = invalidDir.resolve("[INVALID-EXCEL-SHEET-NAME]_"+fileNameWithoutExtension+".csv");
            Files.write(validationFailureFile,List.of("Invalid Excel sheet name. Supported name for DHA: RTCDHA"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void handleRegulatoryFailureResponse(Path raSourceFile,
                                              String raUploadFileName,
                                              String raXmlStr,
                                              String receiverId,
                                              String uploadStatusDesc,
                                              String errorReport){
        try {
            String currentDate =
                    DateUtils.now(LocalDateTime.now(),AppConstants._RA_FOLDER_FORMAT);
            String fileNameWithoutExtension = FilenameUtils.removeExtension(raSourceFile.getFileName().toString());

            Path failureRootDir = Paths.get(raNetworkRootDir).resolve(raFailureDir);
            Path failureDir =  getYearMonthDir(failureRootDir).resolve(DateUtils.currentDate("MMddyyyy"));
            Path errorDir = failureDir.resolve(receiverId).resolve(currentDate.toUpperCase()+"_"+fileNameWithoutExtension);
            Files.createDirectories(errorDir);
            //------- Move Source XLS file -------
            FileUtils.moveFile(raSourceFile, errorDir, raSourceFile.getFileName());
            //------- Write Uploaded RA Xml file content -------
            Path failureRaXmlQualifiedPath = errorDir.resolve(raUploadFileName);
            if(!Files.exists(failureRaXmlQualifiedPath)){
                Files.createFile(failureRaXmlQualifiedPath);
            }
            Files.write(failureRaXmlQualifiedPath, raXmlStr.getBytes());
            //------- Write Error Report -------
            try {
                Path dhaFailureReportFilePath =
                        errorDir.resolve("[DHA-UPLOAD-FAILURE]_"+FilenameUtils.removeExtension(raUploadFileName)+".csv");
                if(!Files.exists(dhaFailureReportFilePath)){
                    Files.createFile(dhaFailureReportFilePath);
                }
                String errorRepo = getErrorReport(errorReport);
                if(!StringUtils.isNullOrEmpty(errorRepo)){
                    Files.write(dhaFailureReportFilePath, errorRepo.getBytes());
                }else{
                    Files.write(dhaFailureReportFilePath, uploadStatusDesc.getBytes());
                }
            } catch (Exception e){
                log.error("Error Report decoding error: "+e.getLocalizedMessage());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void handleApiInvocationResponse(Path raSourceFile,
                                            String raUploadFileName,
                                            String raXmlStr,
                                            String receiverId,
                                            String statusDesc){
        log.error("API IVOCATION ERROR");
        try {
            String currentDate =
                    DateUtils.now(LocalDateTime.now(),AppConstants._RA_FOLDER_FORMAT);
            String fileNameWithoutExtension = FilenameUtils.removeExtension(raSourceFile.getFileName().toString());

            Path failureRootDir = Paths.get(raNetworkRootDir).resolve(raFailureDir);
            //Path failureDir =  getYearMonthDir(failureRootDir).resolve(DateUtils.currentDate("MMddyyyy"));
            Path failureDir = getYearMonthDir(failureRootDir).resolve(DateUtils.currentDate("MMddyyyy"))
                    .resolve(receiverId).resolve(currentDate.toUpperCase()+"_"+fileNameWithoutExtension);
            Files.createDirectories(failureDir);
            //------- Move Source XLS file -------
            FileUtils.moveFile(raSourceFile, failureDir, raSourceFile.getFileName());
            //------- Write Uploaded RA Xml file content -------
            Path failureRaXmlQualifiedPath = failureDir.resolve(raUploadFileName);
            if(!Files.exists(failureRaXmlQualifiedPath)){
                Files.createFile(failureRaXmlQualifiedPath);
            }
            Files.write(failureRaXmlQualifiedPath, raXmlStr.getBytes());

            Path validationFailureFile = failureDir.resolve("[API_INVOCATION_ERROR]_"+fileNameWithoutExtension+".csv");
            Files.write(validationFailureFile,List.of(statusDesc));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void handleSuccessResponse(Path raSourceFile, String raUploadFileName, String receiverId, String raXmlStr){

        try {
            String currentDate =
                    DateUtils.now(LocalDateTime.now(),AppConstants._RA_FOLDER_FORMAT);
            String fileNameWithoutExtension = FilenameUtils.removeExtension(raSourceFile.getFileName().toString());

            Path successRootDir = Paths.get(raNetworkRootDir).resolve(raSuccessDir);
            Path successDir = getYearMonthDir(successRootDir)
                                    .resolve(DateUtils.currentDate("MMddyyyy"))
                                    .resolve(receiverId)
                                    .resolve(currentDate.toUpperCase()+"_"+fileNameWithoutExtension);
            Files.createDirectories(successDir);
            //------- Move Source XLS file -------
            FileUtils.moveFile(raSourceFile, successDir, raSourceFile.getFileName());
            //------- Write Uploaded RA Xml file content -------
            Path raXmlQualifiedPath = successDir.resolve(raUploadFileName);
            if(!Files.exists(raXmlQualifiedPath)){
                Files.createFile(raXmlQualifiedPath);
            }
            Files.write(raXmlQualifiedPath, raXmlStr.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Path getYearMonthDir(Path dir){
        String month = LocalDateTime.now().getMonth().toString();
        String year = String.valueOf(LocalDateTime.now().getYear());
        return dir.resolve(year).resolve(month);
    }

    public void initializeDefaultFolders(){
        String month = LocalDateTime.now().getMonth().toString();
        String year = String.valueOf(LocalDateTime.now().getYear());

        Path successYMDir = Paths.get(raNetworkRootDir)
                .resolve(raSuccessDir)
                .resolve(year).resolve(month);

        Path failureYMDir = Paths.get(raNetworkRootDir)
                .resolve(raFailureDir)
                .resolve(year).resolve(month);

        Path invalidYMDir = Paths.get(raNetworkRootDir)
                .resolve(raInvalidDir)
                .resolve(year).resolve(month);

        try {
            Files.createDirectories(successYMDir);
            Files.createDirectories(failureYMDir);
            Files.createDirectories(invalidYMDir);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}
