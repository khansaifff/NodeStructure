package ae.axagulf.regulatory.po.model;

import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Data
//@Builder
@XmlRootElement(name="Activity")
@XmlAccessorType(XmlAccessType.FIELD)
public class Activity {

    @XmlElement(name = "ID")
    private String id;
    @XmlElement(name = "Start")
    private String start;
    @XmlElement(name = "Type")
    private int type;
    @XmlElement(name = "Code")
    private String code;
    @XmlElement(name = "Quantity")
    private String quantity;
    @XmlElement(name = "Net")
    private String net;
    @XmlElement(name = "List")
    private String list;
    @XmlElement(name = "Clinician")
    private String clinician;
    @XmlElement(name = "PriorAuthorizationID")
    private String priorAuthorizationID;
    @XmlElement(name = "Gross")
    private String gross;
    @XmlElement(name = "PatientShare")
    private String patientShare;

    @XmlElement(name = "ActivityPenalty")
    private String activityPenalty;

    @XmlElement(name = "PaymentAmount")
    private String paymentAmount;
    @XmlElement(name = "DenialCode")
    private String denialCode;

    @XmlElement(name = "Comments")
    private String comments;
}
