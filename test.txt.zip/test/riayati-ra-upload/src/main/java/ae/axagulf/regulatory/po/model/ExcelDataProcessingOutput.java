package ae.axagulf.regulatory.po.model;

import ae.axagulf.regulatory.po.model.RaData;
import lombok.Data;

import java.util.LinkedList;
import java.util.List;

@Data
public class ExcelDataProcessingOutput {

    private List<RaData> raDataList;
    private boolean isDataValidatioErrorsExist;
    private LinkedList<String> validationErrors;

}
