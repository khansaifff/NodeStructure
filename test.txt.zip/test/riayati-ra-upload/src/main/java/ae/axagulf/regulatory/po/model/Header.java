package ae.axagulf.regulatory.po.model;

import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Data
//@Builder
@XmlRootElement(name="Header")
@XmlAccessorType(XmlAccessType.FIELD)
public class Header {
    @XmlElement(name = "SenderID")
    private String senderID;
    @XmlElement(name = "ReceiverID")
    private String receiverID;
    @XmlElement(name = "TransactionDate")
    private String transactionDate;
    @XmlElement(name = "RecordCount")
    private String recordCount;
    @XmlElement(name = "DispositionFlag")
    private String dispositionFlag;

    @XmlElement(name = "PayerID")
    private String payerID;

}
