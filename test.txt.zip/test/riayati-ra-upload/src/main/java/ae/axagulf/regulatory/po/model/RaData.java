package ae.axagulf.regulatory.po.model;

import lombok.Builder;
import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Data
//@Builder
//@XmlRootElement(name="Record")
//@XmlAccessorType(XmlAccessType.FIELD)
public class RaData {

    private int rowNum;
    //@XmlElement(name = "AXABatchNumber")
    private String axaBatchNumber;
    //@XmlElement(name = "SenderID")
    private String senderID;
    //@XmlElement(name = "ReceiverID")
    private String receiverID;
    //@XmlElement(name = "ClaimID")
    private String claimID;
    //@XmlElement(name = "Comments")
    private String comments;
    //@XmlElement(name = "ClaimDenialCode")
    private String claimDenialCode;
    //@XmlElement(name = "ClaimIDPayer")
    private String claimIDPayer;
    //@XmlElement(name = "ClaimPaymentReference")
    private String claimPaymentReference;
    //@XmlElement(name = "ActivityUID")
    private String activityUID;
    //@XmlElement(name = "ActivityId")
    private String activityId;
    //@XmlElement(name = "ActivityStart")
    private String activityStart;
    //@XmlElement(name = "ActivityType")
    private int activityType;
    //@XmlElement(name = "ActivityCode")
    private String activityCode;
    //@XmlElement(name = "ActivityQuantity")
    private String activityQuantity;
    //@XmlElement(name = "ActivityNet")
    private String activityNet;
    //@XmlElement(name = "ActivityList")
    private String activityList;
    //@XmlElement(name = "ActivityClinician")
    private String activityClinician;
    //@XmlElement(name = "ActivityPriorAuthorizationID")
    private String activityPriorAuthorizationID;
    //@XmlElement(name = "ActivityGross")
    private String activityGross;
    //@XmlElement(name = "ActivityPatientShare")
    private String activityPatientShare;
    //@XmlElement(name = "ActivityPaymentAmount")
    private String activityPaymentAmount;
    //@XmlElement(name = "ActivityDenialCode")
    private String activityDenialCode;
    //@XmlElement(name = "ProviderId")
    private String providerId;
    //@XmlElement(name = "FacilityId")
    private String facilityId;
    //@XmlElement(name = "DateofSettlement")
    private String dateofSettlement;


}
