package ae.axagulf.regulatory.po.model;

import lombok.Data;

@Data
public class RaUploadResponse {

    private String uploadStatus;
    private String uploadStatusDesc ;
    private String uploadStatusCode;
    private String errorReport;
}
