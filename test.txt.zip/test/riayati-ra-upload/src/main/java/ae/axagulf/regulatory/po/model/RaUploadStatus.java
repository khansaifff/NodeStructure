package ae.axagulf.regulatory.po.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RaUploadStatus {
    private String fileName;
    private String uploadDate;
    private String status;
    private String statusDesc;
}
