package ae.axagulf.regulatory.po.model;

import ae.axagulf.regulatory.po.model.Activity;
import ae.axagulf.regulatory.po.model.Claim;
import ae.axagulf.regulatory.po.model.Encounter;
import ae.axagulf.regulatory.po.model.Header;
import lombok.Data;

import javax.xml.bind.annotation.*;
import java.io.Serializable;
import java.util.List;

@Data
//@Builder
@XmlRootElement(name="Remittance.Advice")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlSeeAlso({Header.class, Claim.class, Encounter.class, Activity.class})
public class RemittanceAdvice implements Serializable {
    @XmlElement(name = "Header")
    private Header Header;
    @XmlElement(name = "Claim")
    private List<Claim> Claim;
}
