package ae.axagulf.regulatory.po.services;

import ae.axagulf.regulatory.po.utils.AppConstants;
import ae.axagulf.rest.adapter.*;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Log4j2
public class RaUploadService {

    @Value("${riayati.ra.upload.wsUrl}")
    String riayatiWsUrl;

    @Value("${axa.http.proxy.host}")
    String proxyHost;

    @Value("${axa.http.proxy.port}")
    int proxyPort;

    @Value("${riayati.api.call.via.proxy}")
    boolean isRiayatiApiCallViaProxy;

    @Value("${riayati.ra.api.request.timeout}")
    int riayatiApiRequestTimeout;

    @Value("${riayati.ws.un}")
    String riayatiWsUname;

    @Value("${riayati.ws.pwd}")
    String riayatiWsPwd;

    public CallResponseV2 uploadRaFile(String fileName, String jsonStr) {
//        if (StringUtils.isNullOrEmpty(xmlStr)) {
//            throw new RuntimeException(String.format("Invalid RA XML FOUND FOR UPLOAD FILE: [%s] "+fileName));
//        }
//        String xmlEncodedString = FileUtils.readXmlEncoded(xmlStr);
//
//        String uploadRaTxnRestBody =
//                String.format(AppConstants._UPLOAD_RA_TXN, riayatiWsUname, riayatiWsPwd, xmlEncodedString, fileName);
        RESTAdapterV2 restAdapter = new RESTAdapterV2();
        CallRequestV2 callRequest = getDhpoWsSoapRequest(AppConstants._UPLOAD_RA_TXN_SOAP_ACTION, jsonStr);
        return restAdapter.call(callRequest);
    }

    public CallRequestV2 getDhpoWsSoapRequest(String soapAction, String restBody) {
        CallRequestV2 callRequest = new CallRequestV2();
        callRequest.setProxyHost(proxyHost);
        callRequest.setProxyPort(proxyPort);
        callRequest.setViaProxy(isRiayatiApiCallViaProxy);
        callRequest.setRestAction(soapAction);
        callRequest.setRestBodyJSON(restBody);
        callRequest.setServiceURL(riayatiWsUrl);
        callRequest.setRequestTimeout(riayatiApiRequestTimeout);
        callRequest.setUserName(riayatiWsUname);
        callRequest.setPassWord(riayatiWsPwd);
        return callRequest;
    }
}
