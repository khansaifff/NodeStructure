package ae.axagulf.regulatory.po.services;



import ae.axagulf.regulatory.po.utils.AppConstants;

import ae.axagulf.soap.adapter.CallRequest;
import ae.axagulf.soap.adapter.CallResponse;
import ae.axagulf.soap.adapter.SOAPAdapterV2;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@Log4j2
public class RaUploadServiceV2 {

    @Value("${riayati.ra.upload.wsUrl}")
    String riayatiWsUrl;

    @Value("${axa.http.proxy.host}")
    String proxyHost;

    @Value("${axa.http.proxy.port}")
    int proxyPort;

    @Value("${riayati.api.call.via.proxy}")
    boolean isRiayatiApiCallViaProxy;

    @Value("${riayati.ra.api.request.timeout}")
    int riayatiApiRequestTimeout;

    @Value("${riayati.ws.un}")
    String riayatiWsUname;

    @Value("${riayati.ws.pwd}")
    String riayatiWsPwd;

    public CallResponse uploadRaFile(String fileName, String jsonStr) {
        CallRequest callRequest = buildCallRequest(AppConstants._UPLOAD_RA_TXN_SOAP_ACTION, jsonStr);
        SOAPAdapterV2 adapterV2 = new SOAPAdapterV2();
        return adapterV2.call(callRequest);
    }

    public CallRequest buildCallRequest(String soapAction, String restBody) {
        CallRequest callRequest = new CallRequest();

        callRequest.setProxyHost(proxyHost);
        callRequest.setProxyPort(proxyPort);
        callRequest.setViaProxy(isRiayatiApiCallViaProxy);
        callRequest.setServiceURL(riayatiWsUrl);
        //callRequest.setRequestTimeout(riayatiApiRequestTimeout);
        Map<String, String> reqHeaders = new HashMap<>();
        reqHeaders.put("Content-Type", "application/json");
        reqHeaders.put("username", "INS010");
        reqHeaders.put("password", "vwok@30");
        callRequest.setHttpHeaders(reqHeaders);
        return callRequest;
    }
}
