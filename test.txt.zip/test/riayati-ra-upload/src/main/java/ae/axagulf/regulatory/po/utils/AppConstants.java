package ae.axagulf.regulatory.po.utils;

public class AppConstants {

    public static final String _RA_TXN_DATE_FORMAT = "dd/MM/yyyy HH:mm";
    public static final String _RA_UPLOAD_DATE_NOTIFICATION_FORMAT = "dd/MM/yyyy HH:mm";
    public static final String _RA_FOLDER_FORMAT = "ddMMMyyyy'T'HHmmss";
    public static final String _RA_UPLOAD_FILE_DATE_APPENDED_FORMAT = "MMddyyyy'T'HHmmss";
    public static final String _RA_UPLOAD_SUCCESS = "SUCCESS";
    public static final String _RA_UPLOAD_FAILURE = "FAILURE";

    //1, ClaimID, Mandatory value is either empty or null
    public static final String _RA_DATA_VALIDATION_ERRORS_HEADER_FORMAT = "ROW_NUM, COLUMN_NAME, ERROR_MESSAGE";
    public static final String _RA_DATA_VALIDATION_ERRORS_FORMAT = "%s,%s,%s";
    public static final String _RA_UPLOAD_FAILURE_REPORT_FORMAT = "%s,%s,%s,%s,%s";
    public static final String _RA_DATA_EMPTY_VALUE_ERROR = "Mandatory value is either empty or null";


    public static final String _EXCEL_ATTR_SENDER_ID = "SenderID";
    public static final String _EXCEL_ATTR_RECEIVER_ID = "ReceiverID";
    public static final String _EXCEL_ATTR_CLAIM_ID = "ClaimID";
    public static final String _EXCEL_ATTR_CLAIM_ID_PAYER = "ClaimIDPayer";
    public static final String _EXCEL_ATTR_CLAIM_PAYMENT_REF = "ClaimPaymentReference";
    public static final String _EXCEL_ATTR_ACTIVITY_ID = "ActivityId";
    public static final String _EXCEL_ATTR_ACTIVITY_START = "ActivityStart";
    public static final String _EXCEL_ATTR_ACTIVITY_TYPE = "ActivityType";
    public static final String _EXCEL_ATTR_ACTIVITY_CODE = "ActivityCode";
    public static final String _EXCEL_ATTR_ACTIVITY_QUANTITY = "ActivityQuantity";

    public static final String _EXCEL_ATTR_ACTIVITY_NET = "ActivityNet";
    public static final String _EXCEL_ATTR_ACTIVITY_CLINICIAN = "ActivityClinician";
    public static final String _EXCEL_ATTR_ACTIVITY_PAYMENT_AMOUNT = "ActivityPaymentAmount";


    public static final String _UPLOAD_RA_TXN =
            "<ecl:UploadTransaction xmlns:ecl=\"http://www.eClaimLink.ae/\"><ecl:login>%s</ecl:login><ecl:pwd>%s</ecl:pwd><ecl:fileContent>%s</ecl:fileContent><ecl:fileName>%s</ecl:fileName></ecl:UploadTransaction>";

    public static final String _UPLOAD_RA_TXN_SOAP_ACTION = "http://o-tmbapi.riayati.ae:8083/api/Claim/PostRemittance";
            //"http://www.eClaimLink.ae/UploadTransaction";

    public static final String _RA_ERROR_NAME_IDENTIFIER_INVALID_FILE_EXT = "INVALID-FILE-EXTENSION";
    public static final String _RA_ERROR_NAME_IDENTIFIER_MULTIPLE_EXCEL_SHEETS = "MULTIPLE-EXCEL-SHEETS";
    public static final String _RA_ERROR_NAME_EXCEL_DATA_SHEET_NOT_FOUND = "EXCEL-DATA-SHEET-NOT-FOUND";
    public static final String _RA_ERROR_NAME_EXCLE_READ_UNEXPECTED_ERROR = "EXCEL-READ-UNEXPECTED-ERROR";
    public static final String _RA_INAVALID_FILE_EXTENSION_ERROR = "Invalid File extension found. Supported file extension is [XLS]";
    public static final String _RA_MULTIPLE_EXCEL_SHEETS_MSG = "Number of excel sheets can not be more than 1.";
    public static final String _RA_EXCEL_DATA_SHEET_NOT_FOUND_MSG = "Excel data sheet not found.";

    public static final String _RA_DHPO_UPLOAD_NOTIFICATION_SUBJECT="[DHA Remittance]Upload To DHA Result Report";
    public static final String _RA_DHPO_NOTIFICATION_TEMPLATE_ID = "dhpo_ra_upload_status";



}
