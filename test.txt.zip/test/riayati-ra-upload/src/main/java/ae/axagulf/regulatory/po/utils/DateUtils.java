package ae.axagulf.regulatory.po.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateUtils {

    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    public static String now() {
        LocalDateTime now = LocalDateTime.now();
        return dtf.format(now);
    }



    public static LocalDateTime now(String pattern) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(pattern);
        LocalDateTime now = LocalDateTime.now();
        String localDateTimeStr =  dtf.format(now);
        return LocalDateTime.parse(localDateTimeStr, dtf);
    }

    public static String currentDate(String pattern) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(pattern);
        LocalDateTime now = LocalDateTime.now();
        //String localDateTimeStr =  dtf.format(now);
        return dtf.format(now);
    }

    public static String now(LocalDateTime date, String pattern) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(pattern);
        return dtf.format(date);
    }

//    public static String getDateBasedBatchNumber(){
//        return DateUtils.now(LocalDateTime.now(), AppConstants._BATCH_JOB_NO_DATE_FORMAT);
//    }

}
