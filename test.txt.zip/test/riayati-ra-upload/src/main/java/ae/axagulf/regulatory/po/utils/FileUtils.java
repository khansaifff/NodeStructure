package ae.axagulf.regulatory.po.utils;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.stream.Collectors;

@Log4j2
@Component
public class FileUtils {

//    public void syncPaFiles(Path srcDir, Path targetDir){
//        FileUtils fileUtils = new FileUtils();
//        //String src = "\\\\wp0ora01\\ciris_software\\PA\\PriorAuthorizationReaded\\20210204\\";
//        //String target = "C:/AXA_WORK/CMU/PA_PRD_FILURE_FILES/PA/02042021";
//        try {
//            fileUtils.syncNetworkAndLocalDir(srcDir.toString(), targetDir.toString());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }

    public static void moveFile(Path srcFile, Path destDir, Path destFile){
       if(srcFile == null
               //|| !Files.exists(srcDir)
               //|| !Files.isDirectory(srcDir)
               || destDir == null
               || destFile == null){
           return;
       }
       createDir(destDir);
        try {
            Path destFileAbsPath = destDir.resolve(destFile);
            if(!Files.exists(destFileAbsPath) && Files.createFile(destFileAbsPath) != null ){
                //Files.createFile(destFileAbsPath);
                Files.move(srcFile, destDir.resolve(destFile), StandardCopyOption.REPLACE_EXISTING);
                return;
            }
            Files.move(srcFile, destDir.resolve(destFile));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public  void searchAndCopyFilesInDir(Path searchDir, Path files, Path filesCopyDir){
        try {
            if(!Files.exists(filesCopyDir)){
                Files.createDirectory(filesCopyDir);
            }
            List<Path> filePaths = Files.readAllLines(files).stream()
                    .map(line ->  seachFileByNameInDir(searchDir, line))
                    .collect(Collectors.toList());
            if(filePaths != null || filePaths.size() > 0){
                filePaths.stream()
                        .forEach(fileToCopy ->{
                            if(fileToCopy != null && Files.exists(fileToCopy)){
                                FileUtils.copyFile(fileToCopy, filesCopyDir.resolve(fileToCopy.getFileName().toString()));
                            }
                        });


            }
        }catch (Exception e){
            e.printStackTrace();
            log.error("UNEXPECTED ERROR OCCURED IN searchAndCopyFilesInDir: {}", e.getMessage());
        }
    }

    public static boolean createDir(Path dir){
        try {
            if(Files.exists(dir) || Files.createDirectory(dir) != null){
               return true;
            }
        } catch (IOException e) {
            e.printStackTrace();
            log.error("Directory creation failed: {}", dir);
        }
        return false;
    }



    private Path seachFileByNameInDir(Path searchDir, String fileName){
        try {
            List<Path> results = Files.find(searchDir, 10, (path, attribs)->{
                boolean flag = path.getFileName().toString().equalsIgnoreCase(fileName);
                return flag;
            }).collect(Collectors.toList());
            if(results!= null && results.size() == 1)
                return results.get(0);
            log.info("FILE FOUND: "+results.size()+" - "+results);
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public static String getFileExtension(String filename) {
        return FilenameUtils.getExtension(filename);
    }

    public static void copyFile(Path src, Path target)  {
        Path copied = null;
        try {
            copied = Files.copy(src, target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            e.printStackTrace();
        }
        log.info("File Copied: "+copied);
    }

    public void syncNetworkAndLocalDir(String src, String target) throws IOException {
        String roboCopyCmd =
                String.format("robocopy /S %s %s", src, target);
        Process process = Runtime.getRuntime()
                .exec(roboCopyCmd);
        printResults(process);
        log.info(
                String.format("Files are sync between [%s] and [%s]",
                        src, target));
    }

    private static void printResults(Process process) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        String line = "";
        while ((line = reader.readLine()) != null) {
            System.out.println(line);
        }
    }

    public static String readXmlEncoded(Path path) {
        String encodedString = null;
        try {
            String xml = Files.readString(path);
            encodedString = Base64.getEncoder().encodeToString(xml.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return encodedString;
    }

    public static String readXmlEncoded(String xmlStr) {
        String encodedString = null;
        try {
            encodedString = Base64.getEncoder().encodeToString(xmlStr.getBytes());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return encodedString;
    }

//    public static Set<String> getListOfFiles(String dir, LocalDateTime startDate, LocalDateTime endDate) {
//        Set<String> fileList = new HashSet<>();
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
//        FileFilterDateIntervalUtils filter =
//                new FileFilterDateIntervalUtils(startDate, endDate);
//        File folder = new File(dir);
//        File files[] = folder.listFiles(filter);
//        for (File f : files) {
//            log.info(f.getName() + " "
//                    + sdf.format(new Date(f.lastModified())));
//            fileList.add(f.getName());
//        }
//        return fileList;
//    }

    public static String escapeXml(String s) {
        return s.replaceAll("&", "&amp;")
                .replaceAll(">", "&gt;")
                .replaceAll("<", "&lt;")
                .replaceAll("\"", "&quot;")
                .replaceAll("'", "&apos;");
    }
}
