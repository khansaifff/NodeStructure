package ae.axagulf.regulatory.po.utils;

import java.util.Base64;

public class StringUtils {

    public static final String encode(String decodedStr){
        return Base64.getEncoder().encodeToString(decodedStr.getBytes());
    }

    public static final String decode(String encodedStr){
        return new String(Base64.getDecoder().decode(encodedStr.getBytes()));
    }
}
