package ae.axagulf.rest.adapter;

import java.util.Map;

public class CallRequestV2 {

    public CallRequestV2() {
    }
    public String getServiceURL() {
        return serviceURL;
    }

    public void setServiceURL(String serviceURL) {
        this.serviceURL = serviceURL;
    }

    private String serviceURL;

    public String getRestBodyJSON() {
        return restBodyJSON;
    }

    public void setRestBodyJSON(String restBodyJSON) {
        this.restBodyJSON = restBodyJSON;
    }

    public String getRestHeaderJSON() {
        return restHeaderJSON;
    }

    public void setRestHeaderJSON(String restHeaderJSON) {
        this.restHeaderJSON = restHeaderJSON;
    }

    public String getRestAction() {
        return restAction;
    }

    public void setRestAction(String restAction) {
        this.restAction = restAction;
    }

    public Map<String, String> getHttpHeaders() {
        return httpHeaders;
    }

    public void setHttpHeaders(Map<String, String> httpHeaders) {
        this.httpHeaders = httpHeaders;
    }

    public boolean isViaProxy() {
        return viaProxy;
    }

    public void setViaProxy(boolean viaProxy) {
        this.viaProxy = viaProxy;
    }

    public String getProxyHost() {
        return proxyHost;
    }

    public void setProxyHost(String proxyHost) {
        this.proxyHost = proxyHost;
    }

    public int getProxyPort() {
        return proxyPort;
    }

    public void setProxyPort(int proxyPort) {
        this.proxyPort = proxyPort;
    }

    public int getRequestTimeout() {
        return requestTimeout;
    }

    public void setRequestTimeout(int requestTimeout) {
        this.requestTimeout = requestTimeout;
    }

    private String restBodyJSON;
    private String restHeaderJSON;
    private String restAction;
    private Map<String, String> httpHeaders;
    private boolean viaProxy = false;
    private String proxyHost;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    private String userName;
    private String passWord;
    private int proxyPort;
    private int requestTimeout;


}
