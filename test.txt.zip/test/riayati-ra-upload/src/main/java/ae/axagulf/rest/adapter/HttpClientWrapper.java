package ae.axagulf.rest.adapter;

import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

public class HttpClientWrapper {

    private static final int _MILLI_SECONDS = 1000;

    public HttpClientWrapper() {
    }

    public static CloseableHttpClient wrapClient(CallRequestV2 callRequest) {
        try {
            int requestTimeout = callRequest.getRequestTimeout();
            HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
            if (requestTimeout > 0) {
                System.out.println(String.format("API Request Timeout is configured for [%s] seconds.", requestTimeout));
                RequestConfig config = RequestConfig.custom().setConnectTimeout(requestTimeout * 1000).setConnectionRequestTimeout(requestTimeout * 1000).setSocketTimeout(requestTimeout * 1000).build();
                httpClientBuilder.setDefaultRequestConfig(config);
            }

            if (callRequest.isViaProxy()) {
                System.out.println("API Call is going via proxy server::...");
                String proxyHostIP = callRequest.getProxyHost();
                int proxyPort = callRequest.getProxyPort();
                HttpHost proxy = new HttpHost(proxyHostIP, proxyPort);
                httpClientBuilder.setProxy(proxy);
            }

            SSLContext ctx = SSLContext.getInstance("TLS");
            X509TrustManager tm = new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                }

                public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                }

                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
            };
            ctx.init((KeyManager[])null, new TrustManager[]{tm}, (SecureRandom)null);
            SSLSocketFactory ssf = new SSLSocketFactory(ctx);
            ssf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            CloseableHttpClient client = httpClientBuilder.setSSLContext(ctx).setSSLSocketFactory(ssf).setSSLHostnameVerifier((s1, s2) -> {
                return true;
            }).build();
            return client;
        } catch (Exception var7) {
            var7.printStackTrace();
            return null;
        }
    }

    CloseableHttpClient getHttpsClient() {
        try {
            RequestConfig config = RequestConfig.custom().setSocketTimeout(5000).setConnectTimeout(5000).build();
            SSLContextBuilder sslContextBuilder = new SSLContextBuilder();
            sslContextBuilder.loadTrustMaterial((KeyStore)null, (x509Certificates, s) -> {
                return true;
            });
            SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(sslContextBuilder.build(), NoopHostnameVerifier.INSTANCE);
            return HttpClients.custom().setDefaultRequestConfig(config).setSSLSocketFactory(sslSocketFactory).build();
        } catch (Exception var4) {
            var4.printStackTrace();
            return HttpClients.createDefault();
        }
    }

    /** @deprecated */
    @Deprecated
    public static HttpClient wrapClient(HttpClient base) {
        try {
            SSLContext ctx = SSLContext.getInstance("TLS");
            X509TrustManager tm = new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                }

                public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                }

                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
            };
            ctx.init((KeyManager[])null, new TrustManager[]{tm}, (SecureRandom)null);
            SSLSocketFactory ssf = new SSLSocketFactory(ctx);
            ssf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            ClientConnectionManager ccm = base.getConnectionManager();
            SchemeRegistry sr = ccm.getSchemeRegistry();
            sr.register(new Scheme("https", ssf, 443));
            return new DefaultHttpClient(ccm, base.getParams());
        } catch (Exception var6) {
            var6.printStackTrace();
            return null;
        }
    }

}
