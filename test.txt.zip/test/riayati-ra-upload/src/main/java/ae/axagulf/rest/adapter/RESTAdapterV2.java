package ae.axagulf.rest.adapter;


import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.springframework.http.MediaType;

import java.net.SocketTimeoutException;
import java.net.URI;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class RESTAdapterV2 {

    public CallResponseV2 call(CallRequestV2 callRequest) {
        CallResponseV2 _return = new CallResponseV2();
        _return.setStatus("SUCCESS");
        HttpResponse httpResponse = null;
        HttpPost httpPost = null;


        CallResponseV2 var8;
        try {
            HttpClient httpClient = HttpClientWrapper.wrapClient(callRequest);
            httpPost = this.initiateHttpPost(callRequest);
            httpResponse = httpClient.execute(httpPost);
            if (httpResponse == null) {
                _return.setStatus("ERROR");
                _return.setStatusDesc(String.format("No response returned from target service URL [%s]", callRequest.getServiceURL()));
                CallResponseV2 var26 = _return;
                return var26;
            }

            int statusCode = httpResponse.getStatusLine().getStatusCode();
            _return.setStatusCode(statusCode);
            System.out.println("API Call return status Code::"+statusCode);
            String rawContent = EntityUtils.toString(httpResponse.getEntity(), "UTF-8");
            System.out.println("API Call return status Code::"+statusCode +" and Content::"+rawContent);
            if (!isNullOrEmpty(rawContent)) {
                String soapResponseXML = new String(rawContent);
 //               _return.setSoapResponseXML(soapResponseXML);
//                String soapResponseBodyXML = SoapBodyExtractor.transform(soapResponseXML);
//                String soapResponseBodyXmlUpd = soapResponseBodyXML.trim().replaceFirst("^([\\W]+)<", "<");
//                if (callRequest.isIncludeSoapRespWithoutNS()) {
//                    _return.setSoapBodyWithoutNS(XmlUtils.removeNS(soapResponseBodyXmlUpd));
//                }

//                _return.setSoapBodyUnescapedXML(StringEscapeUtils.unescapeXml(soapResponseBodyXmlUpd));
//                _return.setSoapBodyXML(soapResponseBodyXmlUpd);
                return _return;
            }

            _return.setStatus("ERROR");
            _return.setStatusDesc(String.format("No response content returned from target service URL [%s]", callRequest.getServiceURL()));
            var8 = _return;
        } catch (SocketTimeoutException var23) {
            System.out.println("java.net.SocketTimeoutException: " + var23.getLocalizedMessage());
            _return.setStatus("ERROR");
            _return.setStatusDesc(String.format("API call request timed out in [%s] second(s)", callRequest.getRequestTimeout()));
            _return.setStatusCode(408);
            return _return;
        } catch (Exception var24) {
            System.out.println(var24.getLocalizedMessage());
            var24.printStackTrace();
            _return.setStatus("ERROR");
            _return.setStatusDesc(var24.getMessage());
            _return.setStatusCode(500);
            return _return;
        } finally {
            if (httpPost != null) {
                try {
                    httpPost.releaseConnection();
                } catch (Exception var22) {
                }
            }

        }

        return var8;
    }

    private HttpPost initiateHttpPost(CallRequestV2 callRequest) {
        HttpPost httpPost = null;
                //new HttpPost(callRequest.getServiceURL());

        try {
            HttpGet httpGet = new HttpGet(callRequest.getServiceURL());

            URI uri = new URIBuilder(httpGet.getURI()).build();

//        URI uri = new URIBuilder(httpGet.getURI());
            httpPost = new HttpPost(uri);
//        ((HttpRequestBase) httpGet).setURI(uri);
//        CloseableHttpResponse response = client.execute(httpGet);
//        client.close();


            Map<String, String> headersMap = callRequest.getHttpHeaders();
            if (headersMap == null) {
                headersMap = new HashMap();
            }

            ((Map)headersMap).put("Content-Type", MediaType.APPLICATION_JSON_VALUE);
            ((Map)headersMap).put("Accept", "application/json");

            ((Map)headersMap).put("username", callRequest.getUserName());
            ((Map)headersMap).put("password", callRequest.getPassWord());

            ((Map)headersMap).put("SOAPAction", String.format("\"%s\"", callRequest.getRestAction()));
            Iterator var4 = ((Map)headersMap).entrySet().iterator();

            while(var4.hasNext()) {
                Map.Entry<String, String> entry = (Map.Entry)var4.next();
                Header reqHeader = new BasicHeader((String)entry.getKey(), (String)entry.getValue());
                httpPost.addHeader(reqHeader);
            }

            String soapRequestBodyXmlUpd = null;
//            if (!StringUtils.isNullOrEmpty(callRequest.getSoapBodyXML())) {
//                soapRequestBodyXmlUpd = callRequest.getSoapBodyXML().trim().replaceFirst("^([\\W]+)<", "<");
//            }

//            String soapReqXML = this.getSOAPXML(callRequest.getRestHeaderJSON(), soapRequestBodyXmlUpd);
//            StringEntity body = new StringEntity(soapReqXML);
//            httpPost.setEntity(body);
            StringEntity body = new StringEntity(callRequest.getRestBodyJSON());
            httpPost.setEntity(body);
        } catch (Exception var7) {
            var7.printStackTrace();
        }

        return httpPost;
    }

    private String getSOAPXML(String soapHeader, String soapBody) {
        if (soapBody != null) {
            soapBody = soapBody.replaceAll("(<\\?xml.*?\\?>)", "");
        }

        return String.format("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n   <soapenv:Header/>\n   <soapenv:Body>%s</soapenv:Body>\n</soapenv:Envelope>", soapBody);
    }

    private void setDefaultHeaders(Map<String, String> headersMap) {
        if (headersMap == null) {
            headersMap = new HashMap();
        }

        ((Map)headersMap).put("Content-Type", "text/xml");
        ((Map)headersMap).put("Accept", "application/xml");
        System.out.println(">>> headersMap between" + headersMap);
    }

    public static boolean isNullOrEmpty(String str) {
        return str == null || str.length() == 0;
    }

}
